<?php

$id=$_GET[id];

$lines = file('serv_array.txt');
$service=trim($lines[$id]);
echo $service;

$CLM_URL="http://clm-pm:7070/csm";
$CLM_USER="CloudAdmin";
$CLM_PASSWORD="password";

$login=shell_exec ('/usr/local/bin/clm login --url "'.$CLM_URL.'" --user "'.$CLM_USER.'" --password "'.$CLM_PASSWORD.'" >> /tmp/qr_clm.log');
echo $login;
$req=shell_exec('/usr/local/bin/clm service-create --offeringname "'.$service.'" --servicename "'.$service.'" --serverusername "chris" --serverpassword "Passw0rd1" --serverhostprefix "clmqr" --tenantname "CLM Provider" >> /tmp/qr_clm.log &');
echo $req;
?>
